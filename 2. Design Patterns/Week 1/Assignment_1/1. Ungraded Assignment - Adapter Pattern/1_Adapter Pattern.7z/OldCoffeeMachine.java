/**
 *
 @author Emin on 27/02/2022
 */
public class OldCoffeeMachine {
	
    public void selectA() {}
    public void selectB() {}
	
}