/**
 *
 @author Emin on 27/02/2022
 */

public interface CoffeeMachineInterface {

public void chooseFirstSelection();

public void chooseSecondSelection();

}