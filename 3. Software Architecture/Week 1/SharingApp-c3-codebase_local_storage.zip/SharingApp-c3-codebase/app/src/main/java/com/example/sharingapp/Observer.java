package com.example.sharingapp;

/**
 * Observer Interface
 */
public interface Observer {
    public void update();
}
